package main

import (
	"context"
	"fmt"
	"log"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	//"go.mongodb.org/mongo-driver/mongo/readpref"
)

// You will be using this Trainer type later in the program
type Trainer struct {
	Name string
	Age  int
	City string
}

func main() {
	//Get context
	ctx := context.Background()
	// Create client
	client, err := mongo.NewClient(options.Client().ApplyURI("mongodb://127.0.0.1:27017"))
	if err != nil {
		log.Fatal(err)
	}

	// Create connect
	err = client.Connect(ctx)
	if err != nil {
		log.Fatal(err)
	}

	defer func(ctx context.Context, client *mongo.Client) {
		err = client.Disconnect(ctx)

		if err != nil {
			log.Fatal(err)
		}
		fmt.Println("Connection to MongoDB closed.")
	}(ctx, client)

	// Check the connection
	err = client.Ping(context.TODO(), nil)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Connected to MongoDB!")

	//Create collection
	collection := client.Database("test").Collection("trainers")

	//Create entites
	ash := Trainer{"Ash", 10, "Pallet Town"}
	// misty := Trainer{"Misty", 10, "Cerulean City"}
	// brock := Trainer{"Brock", 15, "Pewter City"}

	//Collection insert one
	insertResult, err := collection.InsertOne(ctx, ash)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Inserted a single document: ", insertResult.InsertedID)

	//find by id
	var result Trainer
	collection.FindOne(ctx, bson.M{"_id": insertResult.InsertedID}).Decode(&result)
	fmt.Println("Find by id result: ", result)

	//Collection insert many
	// trainers := []interface{}{misty, brock}

	// insertManyResult, err := collection.InsertMany(ctx, trainers)
	// if err != nil {
	// 	log.Fatal(err)
	// }

	// fmt.Println("Inserted multiple documents: ", insertManyResult.InsertedIDs)

	//Get document
	//filter := bson.D{{"name", "Ash"}}

	// create a value into which the result can be decoded
	// var result Trainer

	// err = collection.FindOne(ctx, filter).Decode(&result)
	// if err != nil {
	// 	log.Fatal(err)
	// }

	// fmt.Printf("Found a single document: %+v\n", result)

	// Pass these options to the Find method
	options := options.Find()
	options.SetLimit(2)
	filter := bson.M{}

	// Here's an array in which you can store the decoded documents
	var results []*Trainer

	// Passing nil as the filter matches all documents in the collection
	cur, err := collection.Find(ctx, filter, options)
	if err != nil {
		log.Fatal(err)
	}

	// Finding multiple documents returns a cursor
	// Iterating through the cursor allows us to decode documents one at a time
	for cur.Next(ctx) {

		// create a value into which the single document can be decoded
		var elem Trainer
		err := cur.Decode(&elem)
		if err != nil {
			log.Fatal(err)
		}

		results = append(results, &elem)
	}

	if err := cur.Err(); err != nil {
		log.Fatal(err)
	}

	// Close the cursor once finished
	cur.Close(ctx)

	fmt.Printf("Found multiple documents (array of pointers): %+v\n", results)

	//Update entites
	updFilter := bson.D{{"name", "Ash"}}

	//Update object
	entrySet := make([]bson.E, 0)
	entry := bson.E{"age", 5}
	entrySet = append(entrySet, entry)

	setEntity := bson.E{"$set", entrySet}
	setColl := make([]bson.E, 0)
	setColl = append(setColl, setEntity)
	// update := bson.D(setColl)

	// update := bson.D{
	// 	{"$set", bson.D{
	// 		{"age", 25},
	// 	}},
	// }
	updateResult, err := collection.UpdateOne(ctx, updFilter, setColl)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Printf("Matched %v documents and updated %v documents.\n", updateResult.MatchedCount, updateResult.ModifiedCount)

	//Remove entities

	//collection.DeleteOne()
	//collection.DeleteMany()
	//collection.Drop()

	// delFilter := bson.M{}
	// deleteResult, err := collection.DeleteMany(ctx, delFilter)
	// if err != nil {
	// 	log.Fatal(err)
	// }
	// fmt.Printf("Deleted %v documents in the trainers collection\n", deleteResult.DeletedCount)
}
