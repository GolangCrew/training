package main

import (
	"context"
	"fmt"
	"time"
)

func main() {
	// Create a context that is cancellable only manually.
	ctx, cancel := context.WithCancel(context.Background())

	// The cancel function mus be called regardless of the outcome.
	defer cancel()

	// Ask the goroutine to do some work for us.
	go func() {
		// Simulate work
		time.Sleep(150 * time.Millisecond)

		// Report the work is done.
		cancel()
	}()

	// Wait for the work to finish. If it takes too long move on.
	select {
	case <-time.After(100 * time.Millisecond):
		fmt.Println("moving on")
	case <-ctx.Done():
		fmt.Println("work complete")
	}
}
