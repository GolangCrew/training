package main

import (
	"context"
	"fmt"
	"time"
)

func main() {

	// Set a deadline.
	duration := 150 * time.Millisecond

	// Create a context that is both manually cancellable and will signal
	// a cancel at the specificed duration.
	ctx, cancel := context.WithTimeout(context.Background(), duration)
	defer cancel()

	// Create a channel to receive a signal that work is done.
	ch := make(chan struct{}, 1)

	// Ask the goroutine to do some work for us.
	go func() {
		// Simulate work
		time.Sleep(250 * time.Millisecond)

		// Report the work is done.
		ch <- struct{}{}
	}()

	// Wait for the work to finish. If it takes too long move on.
	select {
	case <-ch:
		fmt.Println("work complete")
	case <-ctx.Done():
		fmt.Println("work cancelled")
	}
}
