package main

import (
	"fmt"
	"net/http"
	"time"
)

func handlerOne(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Hello world from One")
	w.Write([]byte("!!!"))
}

func handlerTwo(w http.ResponseWriter, r *http.Request) {
	time.Sleep(10 * time.Second)
	fmt.Fprintln(w, "Hello world from Two")
	w.Write([]byte("!!!"))
}

func main() {
	http.HandleFunc("/", handlerTwo)
	http.HandleFunc("/test", handlerOne)

	fmt.Println("starting server at :8080")
	http.ListenAndServe(":8080", nil)
}
