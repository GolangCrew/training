package main

import (
	"encoding/json"
	"fmt"
	"log"
)

type Pizza struct {
	Name     string `json:"pizza_name"`
	Diameter int    `json:",omitempty"`
	Weight   int    `json:"-"`
}

func main() {
	p := &Pizza{
		Name:     "Cheese",
		Diameter: 0,
		Weight:   500,
	}
	result, err := json.Marshal(p)
	if err != nil {
		log.Print("Something went wrong!")
	}
	fmt.Printf("json string: %s\n", string(result))
}
