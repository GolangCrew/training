package main

import (
	"encoding/json"
	"fmt"
	"log"
)

var jsonStr = `[
	{"name": "Cheese", "diameter": 22, "weight": 500},
	{"id": "Chicken", "diameter": 40, "weight": 500, "comment": "Double cheese"}
]`

func main() {
	data := []byte(jsonStr)

	var pizzas interface{}
	json.Unmarshal(data, &pizzas)
	fmt.Printf("unpacked in empty interface:\n%#v\n\n", pizzas)

	pizza := map[string]interface{}{
		"id":       "Pepperoni",
		"diameter": 36,
	}
	//var pizzaI interface{} = pizza
	result, err := json.Marshal(pizza)
	if err != nil {
		log.Print("Something went wrong!")
	}
	fmt.Printf("json string from map:\n %s\n", string(result))
}
