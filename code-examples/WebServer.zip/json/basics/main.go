package main

import (
	"encoding/json"
	"fmt"
	"log"
)

type Pizza struct {
	Name     string
	Diameter int
	Weight   int
}

var jsonStr = `{"name": "Cheese", "diameter": 35, "weight": 500}`

func main() {
	data := []byte(jsonStr)

	p := &Pizza{}
	json.Unmarshal(data, p)
	fmt.Printf("struct:\n\t%#v\n\n", p)

	p.Weight = 550

	result, err := json.Marshal(p)
	if err != nil {
		log.Print("Something went wrong!")
	}
	fmt.Printf("struct:\n\t%#s\n\n", string(result))
}
