package main

import (
	"log"
)

// result is what is sent back from each operation
type result struct {
	id  int
	op  string
	err error
}

func main() {
	// Set the number pf routines and inserts
	const routines = 10
	const inserts = routines * 2

	//Buffered channel to receive information about any possible insert.
	ch := make(chan result, inserts)

	//Number of responses we need to handle
	waitInserts := inserts

	//Perform all the inserts
	for i := 0; i < routines; i++ {
		go func(id int) {
			ch <- insertUser(id)

			//We don't need to wait to start the second insert
			//The first send will happen immediately
			ch <- insertTrans(id)
		}(i)
	}

	//Process the insert results as they complete
	for waitInserts > 0 {
		//Wait for a response from a goroutine
		r := <-ch

		//Display the result
		log.Printf("N: %d ID: %d OP: %s ERR: %v", waitInserts, r.id, r.op, r.err)

		//Decrement the wait count and determine if we are done.
		waitInserts--
	}

	log.Println("Inserts Complete")
}

// insertUser simulates a database operation.
func insertUser(id int) result {
	r := result{
		id: id,
	}
}

// insertTrans simulates a database operation.
func insertTrans(id int) result {
	r := result{
		id: id,
	}
}
