package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	//basicSendRecv()
	//signalClose()
	//signalAck()
	//closeRange()
	//selectRecv()
	//selectSend()
	selectDrop()
}

func basicSendRecv() {
	ch := make(chan string)
	go func() {
		ch <- "hello"
	}()

	fmt.Println(<-ch)
}

func signalClose() {
	ch := make(chan struct{}) //Empty struct
	go func() {
		time.Sleep(100 * time.Millisecond)
		fmt.Println("signal event")
		close(ch)
	}()

	<-ch
	fmt.Println("event received")
}

//Double signal with ack
func signalAck() {
	ch := make(chan string)
	go func() {
		fmt.Println(<-ch)
		//Perform some useful work
		ch <- "ok done"
	}()

	ch <- "do this"
	fmt.Println(<-ch)
}

//Range close
func closeRange() {
	ch := make(chan int, 5)
	for i := 0; i < 5; i++ {
		ch <- i
	}
	//close(ch)

	fmt.Println(<-ch)
	fmt.Println(<-ch)
	fmt.Println(<-ch)
	fmt.Println(<-ch)
	fmt.Println(<-ch)

	fmt.Println(<-ch) //Additional

	// for v := range ch {
	// 	fmt.Println(v)
	// }
}

//Select
func selectRecv() {
	ch := make(chan string, 1) //Add buffer to fix
	go func() {
		time.Sleep(time.Duration(rand.Intn(200)) * time.Millisecond)
		ch <- "work"
	}()

	select {
	case v := <-ch:
		fmt.Println(v)
	case <-time.After(100 * time.Millisecond): //Bug here
		fmt.Println("timed out")
	}
}

func selectSend() {
	ch := make(chan string)
	go func() {
		time.Sleep(time.Duration(rand.Intn(200)) * time.Millisecond)
		fmt.Println(<-ch)
	}()

	select {
	case ch <- "work":
		fmt.Println("send work")
	case <-time.After(100 * time.Millisecond): //Bug here
		fmt.Println("timed out")
	}
}

func selectDrop() {
	ch := make(chan int, 5)
	go func() {
		for v := range ch {
			fmt.Println("recv", v)
		}
	}()

	for i := 0; i < 20; i++ {
		select {
		case ch <- i:
		default:
			fmt.Println("drop", i)
		}
	}
	close(ch)
	fmt.Scanln()
}
